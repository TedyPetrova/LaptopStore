package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

public class RepController extends LogInController implements Initializable {
    @FXML private TableView<OrdersRows> tableOrders;
    @FXML private TextField date_field_orders;
    @FXML private TextField productID_field_orders;
    @FXML private TextField customerID_orders;
    @FXML private TextField searchOrderID_field;
    @FXML private TextField quantity_orders;
    @FXML private TableColumn<OrdersRows, String> col_order_id;
    @FXML private TableColumn<OrdersRows, String> col_order_date;
    @FXML private TableColumn<OrdersRows, String> col_product_id;
    @FXML private TableColumn<OrdersRows, String> col_customer_id;
    @FXML private TableColumn<OrdersRows, String> col_quantity_orders;
    @FXML private TableView<CustomersRows> tableCustomers;
    @FXML private TableColumn<CustomersRows, String> col_customer_id_customers;
    @FXML private TableColumn<CustomersRows, String> col_customer_name;
    @FXML private TableColumn<CustomersRows, String> col_customer_email;
    @FXML private TableColumn<CustomersRows, String> col_customer_phone;
    @FXML private TextField name_field;
    @FXML private TextField email_field;
    @FXML private TextField phone_field;
    @FXML private TextField searchCustomerID_field;
    @FXML public Button logOut;
    String sql;
    Connection conn;
    int result;
    ResultSet rs;
    Stage modifyCustomerStage;
    Scene modifyCustomerScene;
    public ObservableList<OrdersRows> ordersList = FXCollections.observableArrayList();
    public ObservableList<CustomersRows> customersList = FXCollections.observableArrayList();

    public void logOutAction() throws Exception{
        Stage stage;
        Parent primaryStage;
        stage = (Stage) logOut.getScene().getWindow();
        primaryStage = FXMLLoader.load(getClass().getResource("SceneMain.fxml"));
        Scene scene = new Scene(primaryStage);
        stage.setScene(scene);
        stage.show();
    }
    public void populateOrders(){
        ordersList.clear();
        try {
            Connection conn = MySQLConnection.getConnection();
            rs = conn.createStatement().executeQuery("SELECT * FROM orders WHERE repID = " + getCurrentID());
            while (rs.next()){
                ordersList.add(new OrdersRows(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getInt(6)));
                col_order_id.setCellValueFactory(new PropertyValueFactory<>("idOfOrder"));
                col_order_date.setCellValueFactory(new PropertyValueFactory<>("dateOfOrder"));
                col_product_id.setCellValueFactory(new PropertyValueFactory<>("laptops_Product_id"));
                col_customer_id.setCellValueFactory(new PropertyValueFactory<>("customers_Customer_id"));
                col_quantity_orders.setCellValueFactory(new PropertyValueFactory<>("quantity"));
                tableOrders.setItems(ordersList);
            }
        } catch (SQLException exc) {
            exc.printStackTrace();
            Alert message = new Alert(Alert.AlertType.ERROR);
            message.setContentText(exc.getMessage());
            message.show();
        }
    }
    public void addOrder(){
        try {
            sql = "INSERT INTO orders (dateOfOrder, laptops_Product_id, customers_Customer_id, repID, quantity) VALUES ('"+date_field_orders.getText()+"',"+"'"+productID_field_orders.getText()+"','"+customerID_orders.getText()+"','"+getCurrentID()+"','"+Integer.parseInt(quantity_orders.getText())+"')";
            conn = MySQLConnection.getConnection();
            Statement stmt = conn.createStatement();
            result = stmt.executeUpdate(sql);
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            Alert message = new Alert(Alert.AlertType.ERROR);
            message.setContentText(ex.getMessage());
            message.show();
        }
        populateOrders();
        date_field_orders.clear();
        productID_field_orders.clear();
        customerID_orders.clear();
        quantity_orders.clear();
    }
    public void searchOrder(){
        ObservableList<OrdersRows> filteredOrders = FXCollections.observableArrayList();
        try {
            sql = "SELECT * FROM orders WHERE idOfOrder = '" +searchOrderID_field.getText() +"'AND repID = '"+getCurrentID()+"'";
            conn = MySQLConnection.getConnection();
            Statement stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            while (rs.next()){
                filteredOrders.add(new OrdersRows(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getInt(6)));
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            Alert message = new Alert(Alert.AlertType.ERROR);
            message.setContentText(ex.getMessage());
            message.show();
        }
        col_order_id.setCellValueFactory(new PropertyValueFactory<>("idOfOrder"));
        col_order_date.setCellValueFactory(new PropertyValueFactory<>("dateOfOrder"));
        col_product_id.setCellValueFactory(new PropertyValueFactory<>("laptops_Product_id"));
        col_customer_id.setCellValueFactory(new PropertyValueFactory<>("customers_Customer_id"));
        col_quantity_orders.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        tableOrders.setItems(filteredOrders);
    }
    public void clearSearchOrders(){
        searchOrderID_field.clear();
        tableOrders.setItems(ordersList);
    }
    public int getLaptopQuantity() throws SQLException {
        sql = "SELECT * FROM laptops WHERE Product_id = "+"'"+productID_field_orders.getText()+"'";
        try {
            Connection conn = MySQLConnection.getConnection();
            Statement stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
        } catch (SQLException exc) {
            exc.printStackTrace();
            Alert message = new Alert(Alert.AlertType.ERROR);
            message.setContentText(exc.getMessage());
            message.show();
        }
        rs.next();
        int quantityLaptop = rs.getInt(7);
        return quantityLaptop;
    }
    public void changeLaptopQuantity() throws SQLException {
        System.out.println(quantity_orders.getText());
        System.out.println(productID_field_orders.getText());
        sql = "UPDATE laptops SET Quantity = Quantity-"+Integer.parseInt(quantity_orders.getText())+" WHERE Product_id = '"+Integer.parseInt(productID_field_orders.getText())+"'";
        try {
            conn = MySQLConnection.getConnection();
            Statement stmt = conn.createStatement();
            result = stmt.executeUpdate(sql);
        } catch (SQLException exc) {
            exc.printStackTrace();
            Alert message = new Alert(Alert.AlertType.ERROR);
            message.setContentText(exc.getMessage());
            message.show();
        }
    }
    public void buyLaptop() throws SQLException {
        if (getLaptopQuantity()>=Integer.parseInt(quantity_orders.getText())){
            changeLaptopQuantity();
            addOrder();
        }
        else{
            Alert message = new Alert(Alert.AlertType.ERROR);
            message.setContentText("Not enough products");
            message.show();
        }
    }

    public void populateCustomers(){
        customersList.clear();
        try {
            conn = MySQLConnection.getConnection();
            rs = conn.createStatement().executeQuery("SELECT * FROM customers WHERE repID = " + getCurrentid());
            while (rs.next()){
                 customersList.add(new CustomersRows(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5)));
                 col_customer_id_customers.setCellValueFactory(new PropertyValueFactory<>("id"));
                 col_customer_name.setCellValueFactory(new PropertyValueFactory<>("name"));
                 col_customer_email.setCellValueFactory(new PropertyValueFactory<>("mail"));
                 col_customer_phone.setCellValueFactory(new PropertyValueFactory<>("phone"));
                 tableCustomers.setItems(customersList);
            }
        } catch (SQLException exc) {
            exc.printStackTrace();
            Alert message = new Alert(Alert.AlertType.ERROR);
            message.setContentText(exc.getMessage());
            message.show();
        }
    }
    public void addCustomer() throws SQLException {
        sql = "INSERT INTO customers (name, mail, phone, repID) VALUES ('"+name_field.getText()+"',"+"'"+email_field.getText()+"','"+phone_field.getText()+"','"+getCurrentID()+"')";
        try {
            conn = MySQLConnection.getConnection();
            Statement stmt = conn.createStatement();
            result = stmt.executeUpdate(sql);
            populateCustomers();
            }
        catch (SQLException ex) {
            System.out.println(ex.getMessage());
            Alert message = new Alert(Alert.AlertType.ERROR);
            message.setContentText(ex.getMessage());
            message.show();
            }
        name_field.clear();
        email_field.clear();
        phone_field.clear();
    }
    public void searchCustomer(){
        ObservableList<CustomersRows> filteredCustomers = FXCollections.observableArrayList();
        try {
            sql = "SELECT * FROM customers WHERE id = '" +searchCustomerID_field.getText()+"'AND repID = '"+getCurrentID()+"'";
            conn = MySQLConnection.getConnection();
            Statement stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            while (rs.next()){
                filteredCustomers.add(new CustomersRows(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5)));
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            Alert message = new Alert(Alert.AlertType.ERROR);
            message.setContentText(ex.getMessage());
            message.show();
        }
        col_customer_id_customers.setCellValueFactory(new PropertyValueFactory<>("id"));
        col_customer_name.setCellValueFactory(new PropertyValueFactory<>("name"));
        col_customer_email.setCellValueFactory(new PropertyValueFactory<>("mail"));
        col_customer_phone.setCellValueFactory(new PropertyValueFactory<>("phone"));
        tableCustomers.setItems(filteredCustomers);
    }
    public void clearSearchCustomers(){
        searchCustomerID_field.clear();
        tableCustomers.setItems(customersList);
    }
    public void deleteCustomer(){
        sql = "DELETE FROM customers WHERE id = " +searchCustomerID_field.getText();
        try {
            conn = MySQLConnection.getConnection();
            Statement stmt = conn.createStatement();
            result = stmt.executeUpdate(sql);
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            Alert message = new Alert(Alert.AlertType.ERROR);
            message.setContentText(ex.getMessage());
            message.show();
        }
        populateCustomers();
        searchCustomerID_field.clear();
    }
    public void modifyCustomerButton() throws IOException {
        modifyCustomerStage = new Stage();
        modifyCustomerScene = new Scene(FXMLLoader.load(getClass().getResource("ModifyCustomer.fxml")));
        modifyCustomerStage.initStyle(StageStyle.UNDECORATED);
        modifyCustomerStage.getScene();
        modifyCustomerStage.setScene(modifyCustomerScene);
        modifyCustomerStage.show();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        populateOrders();
        populateCustomers();
    }
}
