package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class RepController extends LogInController implements Initializable {
    @FXML private TableView<OrdersRows> tableOrders;
    @FXML private TableColumn<OrdersRows, String> col_order_id;
    @FXML private TableColumn<OrdersRows, String> col_order_date;
    @FXML private TableColumn<OrdersRows, String> col_product_id;
    @FXML private TableColumn<OrdersRows, String> col_customer_id;
    @FXML private TableView<CustomersRows> tableCustomers;
    @FXML private TableColumn<CustomersRows, String> col_customer_id_customers;
    @FXML private TableColumn<CustomersRows, String> col_customer_name;
    @FXML private TableColumn<CustomersRows, String> col_customer_email;
    @FXML private TableColumn<CustomersRows, String> col_customer_phone;
    @FXML public Button logOut;
    String sql;
    Connection conn;
    int result;
    ResultSet rs;
    public ObservableList<OrdersRows> ordersList = FXCollections.observableArrayList();

    public void logOutAction() throws Exception{
        Stage stage;
        Parent primaryStage;
        stage = (Stage) logOut.getScene().getWindow();
        primaryStage = FXMLLoader.load(getClass().getResource("SceneMain.fxml"));
        Scene scene = new Scene(primaryStage);
        stage.setScene(scene);
        stage.show();
    }
    public void populateOrders(){
        ordersList.clear();
        try {
            Connection conn = MySQLConnection.getConnection();
            rs = conn.createStatement().executeQuery("SELECT * FROM orders WHERE repID = " + getCurrentID());
            while (rs.next()){
                ordersList.add(new OrdersRows(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5)));
                col_order_id.setCellValueFactory(new PropertyValueFactory<>("idOfOrder"));
                col_order_date.setCellValueFactory(new PropertyValueFactory<>("dateOfOrder"));
                col_product_id.setCellValueFactory(new PropertyValueFactory<>("laptops_Product_id"));
                col_customer_id.setCellValueFactory(new PropertyValueFactory<>("customers_Customer_id"));
                tableOrders.setItems(ordersList);
            }
        } catch (SQLException exc) {
            exc.printStackTrace();
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        populateOrders();
    }
}
