package sample;

public class OrdersRows {
    String idOfOrder, dateOfOrder, laptops_Product_id, customers_Customer_id, RepID;
    int Quantity;
    public OrdersRows(String idOfOrder, String dateOfOrder, String laptops_Product_id, String customers_Customer_id, String repID, int quantity){
        this.idOfOrder = idOfOrder;
        this.dateOfOrder = dateOfOrder;
        this.laptops_Product_id = laptops_Product_id;
        this.customers_Customer_id = customers_Customer_id;
        this.RepID = repID;
        this.Quantity = quantity;
    }

    public String getIdOfOrder() {
        return idOfOrder;
    }

    public String getDateOfOrder() {
        return dateOfOrder;
    }

    public String getLaptops_Product_id() {
        return laptops_Product_id;
    }

    public String getCustomers_Customer_id() {
        return customers_Customer_id;
    }

    public String getRepID() {
        return RepID;
    }

    public int getQuantity() {
        return Quantity;
    }
}
