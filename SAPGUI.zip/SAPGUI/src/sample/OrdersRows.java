package sample;

public class OrdersRows {
    String idOfOrder, dateOfOrder, laptops_Product_id, customers_Customer_id;
    public OrdersRows(String idOfOrder, String dateOfOrder, String laptops_Product_id, String customers_Customer_id){
        this.idOfOrder = idOfOrder;
        this.dateOfOrder = dateOfOrder;
        this.laptops_Product_id = laptops_Product_id;
        this.customers_Customer_id = customers_Customer_id;
    }
}
