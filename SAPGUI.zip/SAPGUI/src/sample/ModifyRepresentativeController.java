package sample;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

public class ModifyRepresentativeController extends AdminController implements Initializable {
    @FXML private TextField newValueRep_field;
    @FXML private TextField repID_field;
    @FXML private ChoiceBox<String> choiceBoxReps;
    @FXML private Button closeButton;
    public void initialize(URL url, ResourceBundle resourceBundle) {
        setChoiceBoxRepresentatives();
    }
    public void setChoiceBoxRepresentatives(){
        choiceBoxReps.getItems().add("ID");
        choiceBoxReps.getItems().add("Name");
        choiceBoxReps.getItems().add("Pass");
        choiceBoxReps.setValue("ID");
    }
    public void modifyButtonAction(){
        sql = "UPDATE representatives SET "+choiceBoxReps.getValue()+"="+"'"+newValueRep_field.getText()+"'"+"WHERE col ="+repID_field.getText();
        try {
            conn = MySQLConnection.getConnection();
            Statement stmt = conn.createStatement();
            result = stmt.executeUpdate(sql);
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

    }
    public void closeButtonAction(){
        modifyLaptopStage = (Stage) closeButton.getScene().getWindow();
        modifyLaptopStage.hide();
    }
}
