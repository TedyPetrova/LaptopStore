package sample;

public class RepresentativesRows {
    String Representative_id, Name, Col;
    public RepresentativesRows(String representative_id, String name, String col){
        this.Representative_id = representative_id;
        this.Name = name;
        this.Col = col;
    }

    public String getRepresentative_id() {
        return Representative_id;
    }

    public String getName() {
        return Name;
    }

    public String getCol() {
        return Col;
    }
}
