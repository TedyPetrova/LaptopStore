package sample;

public class RepresentativesRows {
    String Representative_id, Name, Col, Password;
    public RepresentativesRows(String representative_id, String name, String col, String password){
        this.Representative_id = representative_id;
        this.Name = name;
        this.Col = col;
        this.Password = password;
    }

    public String getRepresentative_id() {
        return Representative_id;
    }

    public String getName() {
        return Name;
    }

    public String getCol() {
        return Col;
    }

    public String getPass() {
        return Password;
    }
}
