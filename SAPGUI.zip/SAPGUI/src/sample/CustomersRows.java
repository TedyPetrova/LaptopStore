package sample;

public class CustomersRows {
    String id, name, mail, phone, repID;
    public CustomersRows(String id, String name, String mail, String phone, String repID){
        this.id = id;
        this.name = name;
        this.mail = mail;
        this.phone = phone;
        this.repID = repID;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getMail() {
        return mail;
    }

    public String getPhone() {
        return phone;
    }

    public String getRepID() {
        return repID;
    }
}
