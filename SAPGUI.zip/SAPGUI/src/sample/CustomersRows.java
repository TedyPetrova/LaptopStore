package sample;

public class CustomersRows {
    String ID, Name, Email, Phone;
    public CustomersRows(String id, String name, String email, String phone){
        this.ID = id;
        this.Name = name;
        this.Email = email;
        this.Phone = phone;
    }
}
