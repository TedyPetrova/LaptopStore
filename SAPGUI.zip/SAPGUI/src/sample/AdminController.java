package sample;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class AdminController {
    @FXML Button logOut;
        public void logOutAction(javafx.scene.input.MouseEvent mouseEvent) throws Exception{
            Stage stage;
            Parent primaryStage;
            stage = (Stage) logOut.getScene().getWindow();
            primaryStage = FXMLLoader.load(getClass().getResource("SceneMain.fxml"));
            Scene scene = new Scene(primaryStage);
            stage.setScene(scene);
            stage.show();
        }
}
