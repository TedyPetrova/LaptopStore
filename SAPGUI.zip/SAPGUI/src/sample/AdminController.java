package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Tab;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class AdminController implements Initializable {
    @FXML private Tab laptops;
    @FXML private TableView<LaptopsRows> tableLaptops;
    @FXML private TableColumn<LaptopsRows, String> col_Product_id;
    @FXML private TableColumn<LaptopsRows, String> col_Brand;
    @FXML private TableColumn<LaptopsRows, String> col_Model;
    @FXML private TableColumn<LaptopsRows, String> col_Processor;
    @FXML private TableColumn<LaptopsRows, String> col_RAM;
    @FXML private TableColumn<LaptopsRows, String> col_OS;
    @FXML private Tab orders;
    @FXML private Tab representatives;
    @FXML private Button logOut;
    ObservableList<LaptopsRows> laptopsList = FXCollections.observableArrayList();
        public void logOutAction(javafx.scene.input.MouseEvent mouseEvent) throws Exception{
            Stage stage;
            Parent primaryStage;
            stage = (Stage) logOut.getScene().getWindow();
            primaryStage = FXMLLoader.load(getClass().getResource("SceneMain.fxml"));
            Scene scene = new Scene(primaryStage);
            stage.setScene(scene);
            stage.show();
        }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            Connection conn = MySQLConnection.getConnection();
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM laptops");
            while (rs.next()){
                laptopsList.add(new LaptopsRows(rs.getString("Product_id"), rs.getString("Brand"), rs.getString("Model"), rs.getString("Processor"), rs.getString("RAM"), rs.getString("OS")));
            }
        } catch (SQLException exc) {
            exc.printStackTrace();
        }
        col_Product_id.setCellValueFactory(new PropertyValueFactory<>("Product_id"));
        col_Brand.setCellValueFactory(new PropertyValueFactory<>("Brand"));
        col_Model.setCellValueFactory(new PropertyValueFactory<>("Model"));
        col_Processor.setCellValueFactory(new PropertyValueFactory<>("Processor"));
        col_OS.setCellValueFactory(new PropertyValueFactory<>("OS"));
        col_RAM.setCellValueFactory(new PropertyValueFactory<>("RAM"));
        tableLaptops.setItems(laptopsList);
    }
}
