package sample;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class LogInController {
    @FXML Button LogInAdmin;

    public void LogInAdminAction(javafx.scene.input.MouseEvent mouseEvent) throws Exception {
        Stage stage;
        Parent primaryStage;
        stage = (Stage) LogInAdmin.getScene().getWindow();
        primaryStage = FXMLLoader.load(getClass().getResource("SceneAdmin.fxml"));
        Scene scene = new Scene(primaryStage);
        stage.setScene(scene);
        stage.show();
    }
}
