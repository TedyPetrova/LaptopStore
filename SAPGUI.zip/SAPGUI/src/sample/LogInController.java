package sample;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class LogInController {
    @FXML public TextField adminUsername_field;
    @FXML public PasswordField adminPass_field;
    @FXML public Button LogInAdmin;
    @FXML public Label invalidLoginAdmin;
    @FXML public TextField repUsername_field;
    @FXML public PasswordField repPass_field;
    @FXML public Button LogInRep;
    @FXML public Label invalidLoginRep;

    ResultSet rs;
    String sql;
    String sqlRep;
    String sqlDel;
    Stage stage;
    Stage stage2;
    Parent adminStage;
    Parent repStage;
    int result;
    ResultSet resultSet;

    public void exit(){
        System.exit(1);
    }
    public void LogInAdminAction() throws Exception {
        if(adminUsername_field.getText().equals("Tedy") && adminPass_field.getText().equals("pass")){
            stage = (Stage) LogInAdmin.getScene().getWindow();
            adminStage = FXMLLoader.load(getClass().getResource("SceneAdmin.fxml"));
            Scene scene = new Scene(adminStage);
            stage.setScene(scene);
            stage.show();
        }
        else{
            invalidLoginAdmin.setText("Invalid login");
        }
    }
    public void logInRepAction() throws IOException {
        try {
            Connection conn = MySQLConnection.getConnection();
            rs = conn.createStatement().executeQuery("SELECT * FROM representatives");
            while (rs.next()){
                if(repUsername_field.getText().equals(rs.getString(1)) && repPass_field.getText().equals(rs.getString(4))){
                    sqlDel = "DELETE FROM currentsession";
                    Statement stmtDel = conn.createStatement();
                    result = stmtDel.executeUpdate(sqlDel);

                    sqlRep = "INSERT INTO currentsession (repID, pass) VALUES ('" +rs.getString(1)+ "',"+"'"+rs.getString(4)+"')";
                    Statement stmt = conn.createStatement();
                    result = stmt.executeUpdate(sqlRep);

                    stage = (Stage) LogInAdmin.getScene().getWindow();
                    adminStage = FXMLLoader.load(getClass().getResource("SceneRepresentative.fxml"));
                    Scene scene = new Scene(adminStage);
                    stage.setScene(scene);
                    stage.show();
                }
                else{
                    invalidLoginRep.setText("Invalid login");
                }
            }
        } catch (SQLException exc) {
            exc.printStackTrace();
        }
    }
    public String getCurrentID() throws SQLException {
        sql = "SELECT * FROM currentsession";
        try {
            Connection conn = MySQLConnection.getConnection();
            Statement stmt = conn.createStatement();
            resultSet = stmt.executeQuery(sql);
        } catch (SQLException exc) {
            exc.printStackTrace();
        }
        resultSet.next();
        String currID = resultSet.getString(1);
        return currID;
    }
}
