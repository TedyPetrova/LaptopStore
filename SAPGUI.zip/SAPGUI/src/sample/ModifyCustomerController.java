package sample;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

public class ModifyCustomerController extends RepController implements Initializable {
    @FXML private TextField newValueCustomer_field;
    @FXML private TextField customerID_field;
    @FXML private ChoiceBox<String> choiceBoxCustomers;
    @FXML private Button closeButton;
    public void initialize(URL url, ResourceBundle resourceBundle) {
        setChoiceBoxCustomers();
    }
    public void setChoiceBoxCustomers(){
        choiceBoxCustomers.getItems().add("ID");
        choiceBoxCustomers.getItems().add("Name");
        choiceBoxCustomers.getItems().add("Email");
        choiceBoxCustomers.getItems().add("Phone");
        choiceBoxCustomers.setValue("ID");
    }
    public void modifyButtonAction(){
        sql = "UPDATE customers SET "+choiceBoxCustomers.getValue()+"="+"'"+newValueCustomer_field.getText()+"'"+"WHERE id ="+customerID_field.getText();
        try {
            conn = MySQLConnection.getConnection();
            Statement stmt = conn.createStatement();
            result = stmt.executeUpdate(sql);
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            Alert message = new Alert(Alert.AlertType.ERROR);
            message.setContentText(ex.getMessage());
            message.show();
        }
    }
    public void closeButtonAction(){
        modifyCustomerStage = (Stage) closeButton.getScene().getWindow();
        modifyCustomerStage.hide();
    }
}
