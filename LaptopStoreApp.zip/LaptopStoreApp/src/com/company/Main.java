package com.company;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Laptops l1 = new Laptops();
        Orders r1 = new Orders();
        Customers c1 = new Customers();
        c1.showAll();
    }
}
