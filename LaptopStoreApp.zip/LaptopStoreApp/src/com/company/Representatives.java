package com.company;

import java.sql.Connection;
import java.sql.ResultSet;

public class Representatives {
    String sql;
    Connection conn;
    int result;
    ResultSet rs;
}
